<template>
    <div @click="et">{{msg}}</div>
</template>

<script>
    export default {
        data () {
            return {
                msg: 'Hello World!'
            }
        },
        created(){
            
        },
        methods: {
            et (){
                alert("!")
            }
        }
    }
</script>

<style>
    html {
        background: blue;
        color: #fff;
        font-size: 20px;
    }
</style>